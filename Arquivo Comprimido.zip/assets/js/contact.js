const linksList = document.querySelector('ul')

setTimeout(()=>{
    linksList.classList.add('show')
},200)